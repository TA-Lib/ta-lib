
#define HAVE_FLOAT_H 1
#define HAVE_INTTYPES_H 1
#define HAVE_LIMITS_H 1
#define HAVE_LOCALE_H 1
#define HAVE_STDDEF_H 1
#define HAVE_STDINT_H 1
#define HAVE_STDLIB_H 1
#define HAVE_STRING_H 1
#define HAVE_UNISTD_H 1
#define HAVE_WCHAR_H 1
#define HAVE_WCTYPE_H 1
/* #undef HAVE_FLOOR */
#define HAVE_ISASCII 1
#define HAVE_LOCALECONV 1
#define HAVE_MBLEN 1
#define HAVE_MEMMOVE 1
#define HAVE_MEMSET 1
#define HAVE_MODF 1
/* #undef HAVE_POW */
/* #undef HAVE_SQRT */
#define HAVE_STRCASECMP 1
#define HAVE_STRCHR 1
#define HAVE_STRERROR 1
#define HAVE_STRNCASECMP 1
#define HAVE_STRRCHR 1
#define HAVE_STRSTR 1
#define HAVE_STRTOL 1
#define HAVE_STRTOUL 1
#define HAVE_PTRDIFF_T 1
#define HAVE_SIZE_T 1
/* #undef size_t */
/* #undef TM_IN_SYS_TIME */
#define HAVE_STRCOLL 1
#define HAVE_STRFTIME 1
#define HAVE_VPRINTF 1
